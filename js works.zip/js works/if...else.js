let nick = 'Ник'
console.log('Hello, ' + nick);

if(nick.length>6){
    console.log('Ну и длинное же имя!');
}else{
    console.log('Имя у вас не из длинных')
}