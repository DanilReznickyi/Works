let dog = {
    name: 'Bob',
    age: 6,
    legs: 4,
    isAwesome: true
}

dog.bark = function(a){
    console.log("Гав-гав! Меня зовут " + this.name + "!")
}
dog.bark()