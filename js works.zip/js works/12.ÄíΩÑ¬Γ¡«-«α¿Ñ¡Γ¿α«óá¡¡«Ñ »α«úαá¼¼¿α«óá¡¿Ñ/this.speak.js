function speak (){
    console.log(this.sound + ' ! Меня зовут ' + this.name + '!')
}
let cat = {
    name: 'Варежка',
    sound: 'Мяу',
    speak: speak
}
let dog = {
    name: 'Жуля',
    sound: 'Гав',
    speak: speak
}
let pig = {
    name: 'Чарли',
    sound: 'Хрю',
    speak: speak
}

dog.speak()
cat.speak()
pig.speak()