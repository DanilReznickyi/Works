// let compliments = ['апетитна','аристократична','блискуча','розкішна','збудлива','смачненька','запашна','дюймовочка','чудова','грайлива','кльова','кокетлива','цукерочка','красуня','королева','лялечка','любимка','наймиліша','неймовірна','нереальна','першокласна']
// let compliment = compliments[Math.floor(Math.random() * compliments.length)]
// let answerCompliment = []
// let attempts = 10
// let foundMatch = false
// 	for(i = 0; i < compliment.length; i++){
// 		answerCompliment[i] = ' _ '
// 	}
// 	let remainingCompliments = compliment.length
// 	while(remainingCompliments > 0 && attempts > 0){
// 		alert(answerCompliment.join(''))
// 		let guess = prompt('Назви букву, зіронька.')
// 		if(guess === null){
// 			break
// 		} else if(guess.length !== 1){
// 			alert('Будь ласка, всього одну букву, не більше, цукерочка')
// 			let foundMatch = false

// 		} else{
// 			for(j = 0; j < compliment.length; j++){
// 				if(compliment[j] === guess.toLocaleLowerCase()){
// 					answerCompliment[j] = guess.toLocaleLowerCase()
// 					remainingCompliments--
// 					foundMatch = true
// 				}
// 			}
// 		}
// 		if(!foundMatch){
// 			attempts--
// 			alert('Квіточка, в тебе залишилось спроб - ' + attempts)
// 		}
// 		guess = guess.toLocaleLowerCase()
// 	}
// 	alert(answerCompliment.join(''))
// 	alert('Ось твый комплімент, серденько ' + '- ' + compliment)


let compliments = ['апетитна', 'аристократична', 'блискуча', 'розкішна', 'збудлива', 'смачненька', 'запашна', 'дюймовочка', 'чудова', 'грайлива', 'кльова', 'кокетлива', 'цукерочка', 'красуня', 'королева', 'лялечка', 'любимка', 'наймиліша', 'неймовірна', 'нереальна', 'першокласна'];
let compliment = compliments[Math.floor(Math.random() * compliments.length)];
let answerCompliment = [];
let attempts = 10;
let foundMatch = false;

for (let i = 0; i < compliment.length; i++) {
  answerCompliment[i] = ' _ ';
}

let remainingCompliments = compliment.length;

while (remainingCompliments > 0 && attempts > 0) {
  alert(answerCompliment.join(''));
  let guess = prompt('Назви букву, зіронька.');

  if (guess === null) {
    break;
  } else if (guess.length !== 1) {
    alert('Будь ласка, введіть лише одну букву, цукерочка');
  } else {
    foundMatch = false;
    guess = guess.toLowerCase();

    for (let j = 0; j < compliment.length; j++) {
      if (compliment[j] === guess && answerCompliment[j] === ' _ ') {
        answerCompliment[j] = guess;
        remainingCompliments--;
        foundMatch = true;
      }
    }

    if (!foundMatch) {
      attempts--;
      alert('Квіточка, в тебе залишилось спроб - ' + attempts);
    }
  }
}

alert(answerCompliment.join(''));
alert('Ось твій комплімент, серденько: ' + compliment);
