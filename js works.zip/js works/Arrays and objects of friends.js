let anna = {
    name: 'Anna',
    age:  18,
    luckyNumbers: [2,4,8,16]
};
let dave = {
    name: 'Dave',
    age:  19,
    luckyNumbers: [3,9,40]
};
let kate = {
    name: 'Kate',
    age:  20,
    luckyNumbers: [1,2,3]
}

let friends = [anna,dave,kate]
console.log(friends)

console.log(friends[1])

console.log(friends[2].name)

console.log(friends[0].luckyNumbers)

console.log(friends[2].luckyNumbers[2])