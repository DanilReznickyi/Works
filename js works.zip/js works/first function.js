let myFirstFunction = function(){
    console.log('Hello');
}

myFirstFunction()