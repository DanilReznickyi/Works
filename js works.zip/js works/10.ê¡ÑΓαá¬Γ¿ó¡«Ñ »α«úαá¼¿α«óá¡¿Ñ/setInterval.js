let counter = 5
function printMassage(){
	console.log('Ты смотришь в консоль уже ' + counter + ' сек')
	counter+=5
}
let intervalId= setInterval(printMassage, 5000)
// clearInterval(intervalId)
