let myArray = [3,2,1]
console.log(myArray.join(' больше, чем '))