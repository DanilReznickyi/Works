let arrayAnimals = ['Cat', 'Dog', 'Lama']
console.log(arrayAnimals.length)

arrayAnimals.push('Fish')
console.log(arrayAnimals)

arrayAnimals.unshift('Bear')
console.log(arrayAnimals)

let firstAnimal = arrayAnimals.shift()
console.log(firstAnimal)
console.log(arrayAnimals)

let lastAnimal = arrayAnimals.pop()
console.log(lastAnimal)
console.log(arrayAnimals)

arrayAnimals.unshift(firstAnimal)
arrayAnimals.push(lastAnimal)
console.log(arrayAnimals)



