let movies = {
	'В поисках Немо': {
		realeaseDate: 2003,
		duration: 100,
		actors:["Альберт Брукс", "Эллен Дедженерес","Александр Гоулд"],
		format:'DVD'
	},
	'Звездные войны': {
		realeaseDate: 1983,
		duration: 134,
		actors:["Марк Хэмилл", "Харрисон Форд", "Кэрри Фишер"],
		format:'DVD'
	},
	'Гарри Поттер и Кубок огня': {
		realeaseDate: 2005,
		duration: 157,
		actors:["Дэниел Рэдклифф", "Эмма Уотсон", "Руперт Гринт"],
		format: "Blu-ray"
	},
};


let findingNemo = movies['В поисках Немо']
let starWars = movies['Звездные войны']
let garryPotter = movies['Гарри Поттер и Кубок огня']

console.log(findingNemo)
console.log(starWars.realeaseDate, starWars.duration)
console.log(garryPotter.format)


let cars = {
	releaseDate: 2006,
 duration: 117,
 actors: ["Оуэн Уилсон", "Бонни Хант", "Пол Ньюман"],
 format: "Blu-ray"
};

movies['Тачки'] = cars
console.log(movies)

console.log(Object.keys(movies))