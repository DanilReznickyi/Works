function drawCats (howManyTimes) {
    for(i = 0; i < howManyTimes; i++){
        console.log(i + '=^.^=');
    }
}

drawCats(100)