let randomBodyParts = ['глаз','нос','череп']
let randomAbjektives = ['вонючее','противное','дурацкое']
let randomAnimalParts = ['лапа','ус','хвост',]
let randomWords = ['мухи','выдры','дубины','мартышки','крысы']
let start = ['У тебя']
let mid = ['еще более']
let end = [',чем']

let randomBodyPart = randomBodyParts[Math.floor(Math.random()*3)]
let randomAbjektive = randomAbjektives[Math.floor(Math.random()*3)]
let randomAnimalPart = randomAnimalParts[Math.floor(Math.random()*3)]
let randomWord =  randomWords[Math.floor(Math.random() *randomWords.length)]

let caller = [start, randomBodyPart, mid, randomAbjektive,end,randomAnimalPart, randomWord].join(' ')

console.log(caller)