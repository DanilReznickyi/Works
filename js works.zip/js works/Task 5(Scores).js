let scores = {
    'Danil': 0,
    'Ighor': 0,
    'Arkadiy': 0
}

scores.Danil = 10
scores.Ighor = 5
console.log(scores)