let namesBody = ['глаз','жепа','ухо']
let abjectives = ['вонючая','дырявая','пробитая']
let animals = ['крыса','выдра','мышь','обузьяна','коала']
let start = 'У тебя '
let mid = ' словно '
let end = '!!!'

let nameBody = namesBody[Math.floor(Math.random()*3)]
let abjective = abjectives[Math.floor(Math.random()*3)]
let animal = animals[Math.floor(Math.random()*5)]

let program = start + nameBody + mid + abjective + ' ' + animal + end

console.log(program)