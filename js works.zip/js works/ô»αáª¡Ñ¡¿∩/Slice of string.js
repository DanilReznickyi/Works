let longString = 'Эта длинная строка такая длинная'
console.log(longString.slice(4,18))
console.log(longString.slice(4))