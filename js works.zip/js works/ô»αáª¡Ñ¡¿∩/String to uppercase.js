let stringUp = 'hello danil'
console.log(stringUp.toUpperCase())

let stringLow = stringUp
console.log(stringLow.toLowerCase())


//Variant 1
let practic = 'эЙ, кАК деЛа?'
let practicLow = practic.toLowerCase()
let practicUpCharacter = practicLow[0]
let practicUp = practicUpCharacter.toLocaleUpperCase()
let slice = practicLow.slice(1)
let finish =  practicUp + slice
console.log(finish)

//Variant 2
console.log(practic[0].toUpperCase() + practic.slice(1).toLowerCase())



