console.log('Самаядлиннаястрока'.length)

let java = 'java'
console.log(java.length)
let script = 'script'
console.log(script.length)
let javascript = java + script
console.log(javascript.length)