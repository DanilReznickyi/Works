let myName = 'Danil'
console.log(myName[0])
console.log(myName[1])
console.log(myName[2])
console.log(myName[3])
console.log(myName[4])



//Code Word
let codeWord1 = 'Обернись'
let codeWord2 = 'Неужели'
let codeWord3 = 'Огурцы'
let codeWord4 = 'Липкие'
let codeWord5 = '?!'
console.log(codeWord1[1]+codeWord2[1]+codeWord3[1]+codeWord4[1]+codeWord5[1])



