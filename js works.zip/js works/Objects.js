let cat = {
    legs : 3,
    'full name' : 'Garmonia Morgan',
    'color': 'Cherepahoviy'
};
console.log(cat)
console.log(cat['full name'])
console.log(cat.legs)
console.log(cat.color)


let dog = {name:'Oladushek', age:8,color:'white',bark:'gav gav'}

console.log(Object.keys(cat))
console.log(Object.keys(dog))


let me = {};
me['name'] = 'Danil'
me['age'] = 21
me['color'] = 'brown'
console.log(me)

me.univer = 'HNURE'
console.log(me)