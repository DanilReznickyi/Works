let myCrazyObject = {
    'name': 'Nelepiy Object',
    'some array': [7,9, {purpose: 'putanica', number: 123}, 3.3],
    'random animal': 'Bananovaya Akula'
}

console.log(myCrazyObject["some array"][2].number )