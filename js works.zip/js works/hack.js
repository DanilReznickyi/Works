// // Введені дані
// var sname = "Veronika";
// var surname = "Kapustina";
// var birthdate = "1972";

// // Генерація комбінацій паролів
// var passwordFound = false;

// for (var i = 0; i < 10000; i++) {
//     var password = generatePassword(i); // Функція генерації пароля

//     if (passwordMatches(password, sname, surname, birthdate)) {
//         passwordFound = true;
//         break;
//     }
// }

// if (passwordFound) {
//     displayPassword(password);
// } else {
//     displayErrorMessage();
// }


// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   passwords.push(name);
//   passwords.push(surname);
//   passwords.push(birthdate);
//   passwords.push(name + surname);
//   passwords.push(surname + name);

//   return passwords;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var iname = "Veronika";
// var surname = "Kapustina";
// var birthdate = "1972";

// // Генерація паролів
// var generatedPasswords = generatePasswords(iname, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Veronika";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }




// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   // У цьому прикладі використовується випадковий пароль довжиною 6 символів
//   for (var i = 0; i < 1000000; i++) {
//     var password = generateRandomPassword(6);
//     passwords.push(password);
//   }

//   return passwords;
// }

// function generateRandomPassword(length) {
//   var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//   var password = "";

//   for (var i = 0; i < length; i++) {
//     var randomIndex = Math.floor(Math.random() * chars.length);
//     password += chars.charAt(randomIndex);
//   }

//   return password;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var iname = "Veronika";
// var surname = "Kapustina";
// var birthdate = "1972";

// // Генерація паролів
// var generatedPasswords = generatePasswords(iname, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "VeronikaKapustina";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з нової строки
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));







// function generatePasswords(iname, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   passwords.push(iname + surname + birthdate); // Зоякосолапко18.02.1960
//   passwords.push(iname + birthdate); // Зоя18.02.1960
//   passwords.push(surname + iname + birthdate); // Косолапкозоя18.02.1960
//   passwords.push(iname + birthdate.substring(6)); // Зоя60
//   passwords.push(iname + "_" + birthdate.substring(3, 5)); // Зоя_02

//   return passwords;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var iname = "Veronika";
// var surname = "Kapustina";
// var birthdate = "1972";

// // Генерація паролів
// var generatedPasswords = generatePasswords(iname, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Veronika19";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з нової строки
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));









// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних

//   // Варіанти паролів з повним прізвищем
//   passwords.push(name + surname + birthdate); // Зоякосолапко18.02.1960
//   passwords.push(name + birthdate); // Зоя18.02.1960
//   passwords.push(surname + name + birthdate); // Косолапкозоя18.02.1960
//   passwords.push(name + birthdate.substring(6)); // Зоя60
//   passwords.push(name + "_" + birthdate.substring(3, 5)); // Зоя_02

//   // Варіанти паролів зі скороченим прізвищем
//   var shortenedSurname = getShortenedSurname(surname);
//   passwords.push(name + shortenedSurname + birthdate); // Зоякосолапко18.02.1960
//   passwords.push(name + shortenedSurname + birthdate.substring(6)); // Зоякосолапко60
//   passwords.push(name + shortenedSurname + "_" + birthdate.substring(3, 5)); // Зоякосолапко_02

//   // Додаткові варіанти паролів з датою народження
//   var birthYear = birthdate.substring(6);
//   passwords.push(name + birthYear); // Зоя60
//   passwords.push(name + birthdate.substring(3, 5)); // Зоя02
//   passwords.push(shortenedSurname + birthYear); // Косолапко60
//   passwords.push(shortenedSurname + birthdate.substring(3, 5)); // Косолапко02

//   return passwords;
// }

// function getShortenedSurname(surname) {
//   // Логіка скорочення прізвища
//   // Наприклад, якщо прізвище "косолапко", скорочене прізвище може бути "косолап"

//   // Приклад простої логіки для скорочення прізвища до п'яти символів
//   if (surname.length > 5) {
//     return surname.substring(0, 5);
//   }
//   return surname;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "01.10.1972";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "VeronikaKap0110";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з нової строки
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));





// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Логіка скорочення імені
//   // Наприклад, якщо ім'я "Veronika", скорочене ім'я може бути "Nika"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (name === "Veronika") {
//     return "Nika";
//   }
//   return name;
// }

// function getShortenedSurname(surname) {
//   // Логіка скорочення прізвища
//   // Наприклад, якщо прізвище "Kapustina", скорочене прізвище може бути "Kap"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (surname === "Kapustina") {
//     return "Kap";
//   }
//   return surname;
// }

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));








// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Логіка скорочення імені
//   // Наприклад, якщо ім'я "Veronika", скорочене ім'я може бути "Nika"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (name === "Veronika") {
//     return "Nika";
//   }
//   return name;
// }

// function getShortenedSurname(surname) {
//   // Логіка скорочення прізвища
//   // Наприклад, якщо прізвище "Kapustina", скорочене прізвище може бути "Kap"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (surname === "Kapustina") {
//     return "Kap";
//   }
//   return surname;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));






// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Логіка скорочення імені
//   // Наприклад, якщо ім'я "Veronika", скорочене ім'я може бути "Nika"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (name === "Veronika") {
//     return "Nika";
//   }
//   return name;
// }

// function getShortenedSurname(surname) {
//   // Логіка скорочення прізвища
//   // Наприклад, якщо прізвище "Kapustina", скорочене прізвище може бути "Kap"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (surname === "Kapustina") {
//     return "Kap";
//   }
//   return surname;
// }

// function getCharacters() {
//   // Символи, які можуть бути включені в паролі
//   // Додайте інші символи, якщо потрібно
//   var characters = ["-", "_", "."];
//   for (var i = 0; i <= 9; i++) {
//     characters.push(i.toString());
//   }
//   return characters;
// }

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));







// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Логіка скорочення імені
//   // Наприклад, якщо ім'я "Veronika", скорочене ім'я може бути "Nika"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (name === "Veronika") {
//     return "Nika";
//   }
//   return name;
// }

// function getShortenedSurname(surname) {
//   // Логіка скорочення прізвища
//   // Наприклад, якщо прізвище "Kapustina", скорочене прізвище може бути "Kap"
//   // Додайте інші правила скорочення, якщо потрібно
//   if (surname === "Kapustina") {
//     return "Kap";
//   }
//   return surname;
// }

// function getCharacters() {
//   // Символи, які можуть бути включені в паролі
//   // Додайте інші символи, якщо потрібно
//   var characters = ["-", "_", "."];
//   for (var i = 0; i <= 9; i++) {
//     characters.push(i.toString());
//   }
//   return characters;
// }

// function checkPasswords(passwords, targetPassword) {
//   var foundPassword = null;

//   passwords.forEach(function (password) {
//     if (password === targetPassword) {
//       foundPassword = password;
//     }
//   });

//   return foundPassword;
// }

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));







// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);
        
//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);
//       });
//     });
//   });

//   return passwords;
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));






// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   var count = 0; // Лічильник комбінацій
//   var targetCount = 1000000; // Цільова кількість комбінацій

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       if (count >= targetCount) {
//         return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//       }

//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         if (count >= targetCount) {
//           return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//         }

//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

//         count++; // Збільшуємо лічильник комбінацій
//       });
//     });
//   });

//   return passwords;
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));







// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   var count = 0; // Лічильник комбінацій
//   var targetCount = 1000000; // Цільова кількість комбінацій

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       if (count >= targetCount) {
//         return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//       }

//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         if (count >= targetCount) {
//           return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//         }

//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

//         count++; // Збільшуємо лічильник комбінацій
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));









// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   var count = 0; // Лічильник комбінацій
//   var targetCount = 1000000; // Цільова кількість комбінацій

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       if (count >= targetCount) {
//         return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//       }

//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         if (count >= targetCount) {
//           return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//         }

//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

//         count++; // Збільшуємо лічильник комбінацій
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Додайте код для отримання скорочення імені
//   // Наприклад, якщо ви хочете використовувати першу літеру імені:
//   return name.charAt(0);
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));













// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   var count = 0; // Лічильник комбінацій
//   var targetCount = 1000000; // Цільова кількість комбінацій

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       if (count >= targetCount) {
//         return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//       }

//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         if (count >= targetCount) {
//           return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//         }

//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

//         count++; // Збільшуємо лічильник комбінацій
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Додайте код для отримання скорочення імені
//   // Наприклад, якщо ви хочете використовувати першу літеру імені:
//   return name.charAt(0);
// }

// function getShortenedSurname(surname) {
//   // Додайте код для отримання скорочення прізвища
//   // Наприклад, якщо ви хочете використовувати першу частину прізвища:
//   var parts = surname.split(" ");
//   return parts[0];
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));









// function generatePasswords(name, surname, birthdate) {
//   var passwords = [];

//   // Генерація комбінацій паролів на основі введених даних
//   var nameVariations = generateNameVariations(name);
//   var surnameVariations = generateSurnameVariations(surname);

//   var count = 0; // Лічильник комбінацій
//   var targetCount = 1000000; // Цільова кількість комбінацій

//   nameVariations.forEach(function (varName) {
//     surnameVariations.forEach(function (varSurname) {
//       if (count >= targetCount) {
//         return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//       }

//       passwords.push(varName + varSurname + birthdate);
//       passwords.push(varName + birthdate);
//       passwords.push(varSurname + varName + birthdate);
//       passwords.push(varName + birthdate.substring(6));
//       passwords.push(varName + "_" + birthdate.substring(3, 5));

//       // Генерація всіх можливих комбінацій символів для паролів
//       var characters = getCharacters();
//       characters.forEach(function (char) {
//         if (count >= targetCount) {
//           return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
//         }

//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char);
//         passwords.push(varSurname + varName + char + birthdate);
//         passwords.push(varName + birthdate.substring(6) + char);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

//         // Додаткові комбінації символів відділення імені та прізвища
//         passwords.push(varName + char + varSurname + birthdate);
//         passwords.push(varName + birthdate + char + varSurname);
//         passwords.push(varSurname + char + varName + birthdate);
//         passwords.push(varName + char + birthdate.substring(6) + varSurname);
//         passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

//         count++; // Збільшуємо лічильник комбінацій
//       });
//     });
//   });

//   return passwords;
// }

// function generateNameVariations(name) {
//   var variations = [];
//   variations.push(name);
//   variations.push(getShortenedName(name));
//   // Додайте інші варіації імені, якщо потрібно
//   return variations;
// }

// function generateSurnameVariations(surname) {
//   var variations = [];
//   variations.push(surname);
//   variations.push(getShortenedSurname(surname));
//   // Додайте інші варіації прізвища, якщо потрібно
//   return variations;
// }

// function getShortenedName(name) {
//   // Додайте код для отримання скорочення імені
//   // Наприклад, якщо ви хочете використовувати першу літеру імені:
//   return name.charAt(0);
// }

// function getShortenedSurname(surname) {
//   // Додайте код для отримання скорочення прізвища
//   // Наприклад, якщо ви хочете використовувати першу частину прізвища:
//   var parts = surname.split(" ");
//   return parts[0];
// }

// function getCharacters() {
//   // Поверніть список всіх можливих символів, які можуть бути в паролі
//   // Наприклад, якщо ви хочете використовувати символи "-", "_" та ".", то:
//   return ["-", "_", "."];
// }

// // Решта коду без змін

// // Введені дані
// var name = "Veronika";
// var surname = "Kapustina";
// var birthdate = "18.02.1960";

// // Генерація паролів
// var generatedPasswords = generatePasswords(name, surname, birthdate);

// // Перевірка паролів
// var targetPassword = "Цільовий пароль";
// var foundPassword = checkPasswords(generatedPasswords, targetPassword);

// if (foundPassword) {
//   console.log("Знайдено пароль:", foundPassword);
// } else {
//   console.log("Пароль не знайдено");
// }

// // Виведення всіх паролів у консоль з новою строкою
// console.log("Всі згенеровані паролі:");
// console.log(generatedPasswords.join("\n"));





function generatePasswords(name, surname, birthdate) {
  var passwords = [];

  // Генерація комбінацій паролів на основі введених даних
  var nameVariations = generateNameVariations(name);
  var surnameVariations = generateSurnameVariations(surname);

  var count = 0; // Лічильник комбінацій
  var targetCount = 1000000; // Цільова кількість комбінацій

  nameVariations.forEach(function (varName) {
    surnameVariations.forEach(function (varSurname) {
      if (count >= targetCount) {
        return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
      }

      passwords.push(varName + varSurname + birthdate);
      passwords.push(varName + birthdate);
      passwords.push(varSurname + varName + birthdate);
      passwords.push(varName + birthdate.substring(6));
      passwords.push(varName + "_" + birthdate.substring(3, 5));

      // Генерація всіх можливих комбінацій символів для паролів
      var characters = getCharacters();
      characters.forEach(function (char) {
        if (count >= targetCount) {
          return; // Виходимо з функції, якщо досягнута цільова кількість комбінацій
        }

        passwords.push(varName + char + varSurname + birthdate);
        passwords.push(varName + birthdate + char);
        passwords.push(varSurname + varName + char + birthdate);
        passwords.push(varName + birthdate.substring(6) + char);
        passwords.push(varName + "_" + birthdate.substring(3, 5) + char);

        // Додаткові комбінації символів відділення імені та прізвища
        passwords.push(varName + char + varSurname + birthdate);
        passwords.push(varName + birthdate + char + varSurname);
        passwords.push(varSurname + char + varName + birthdate);
        passwords.push(varName + char + birthdate.substring(6) + varSurname);
        passwords.push(varName + "_" + birthdate.substring(3, 5) + char + varSurname);

        count++; // Збільшуємо лічильник комбінацій
      });
    });
  });

  return passwords;
}

function generateNameVariations(name) {
  var variations = [];
  variations.push(name);
  variations.push(getShortenedName(name));
  // Додайте інші варіації імені, якщо потрібно
  return variations;
}

function generateSurnameVariations(surname) {
  var variations = [];
  variations.push(surname);
  variations.push(getShortenedSurname(surname));
  // Додайте інші варіації прізвища, якщо потрібно
  return variations;
}

function getShortenedName(name) {
  // Додайте код для отримання скорочення імені
  // Наприклад, якщо ви хочете використовувати першу літеру імені:
  return name.charAt(0);
}

function getShortenedSurname(surname) {
  // Додайте код для отримання скорочення прізвища
  // Наприклад, якщо ви хочете використовувати першу частину прізвища:
  var parts = surname.split(" ");
  return parts[0];
}

function getCharacters() {
  // Повернення масиву символів для паролів
  return ["-", "_", "."];
}

function checkPasswords(passwords, targetPassword) {
  // Перевірка паролів зі списку
  for (var i = 0; i < passwords.length; i++) {
    if (passwords[i] === targetPassword) {
      return passwords[i]; // Повертаємо знайдений пароль
    }
  }
  return null; // Пароль не знайдено
}

// Решта коду без змін

// Введені дані
var name = "Veronika";
var surname = "Kapustina";
var birthdate = "18.02.1960";

// Генерація паролів
var generatedPasswords = generatePasswords(name, surname, birthdate);

// Перевірка паролів
var targetPassword = "Цільовий пароль";
var foundPassword = checkPasswords(generatedPasswords, targetPassword);

if (foundPassword) {
  console.log("Знайдено пароль:", foundPassword);
} else {
  console.log("Пароль не знайдено");
}

// Виведення всіх паролів у консоль з новою строкою
console.log("Всі згенеровані паролі:");
console.log(generatedPasswords.join("\n"));
