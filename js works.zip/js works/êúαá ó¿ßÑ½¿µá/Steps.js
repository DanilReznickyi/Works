//Step 1
let words = ['программа','макака','оладушек','прекрасный','котенок','жираф',]
let word = words[Math.floor(Math.random() * words.length)]

//Step 2
let answerArray = []
for(i = 0; i < word.length; i++){
	answerArray[i] = '_' 
}
let remainingLetters = word.length