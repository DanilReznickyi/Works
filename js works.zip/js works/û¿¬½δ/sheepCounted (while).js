let sheepCounted = 0
while (sheepCounted <= 10){
	console.log('Овец посчитано: ' + sheepCounted + '!')
	sheepCounted++
}
console.log('Хрррррррррр-псссс')