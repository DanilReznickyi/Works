for( let sheepCounted = 0 ; sheepCounted < 10; sheepCounted++){
	console.log('Овец посчитано: ' + sheepCounted + '!')
}
console.log('Хрррррррррр-псссс')