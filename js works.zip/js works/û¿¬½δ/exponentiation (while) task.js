let exponentiation = 3
while (exponentiation < 10000){
	console.log(exponentiation)
	exponentiation = exponentiation * 3
}
