for( x = 2; x < 10000; x = x * 2){
	console.log(x)
}