let timesToSayHello = 5
for (i = 0; i < timesToSayHello; i++){
	console.log('Hello!')
}