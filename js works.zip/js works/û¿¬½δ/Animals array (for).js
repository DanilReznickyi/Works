let animals = ['лев','фламинго','белый медведь','удав',]
for(i = 0; i < animals.length; i++){
	console.log('В этом зоопарке есть ' + animals[i] + '.')
}