let myName = 'Danil'
for(i = 0; i < myName.length; i++){
	console.log('В моем имени есть буква ' + myName[i] + '.')
}