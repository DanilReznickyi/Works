let myName = 'Sophiya'

if (myName === 'Danil'){
	console.log('Привет, Данил!')
} else if (myName === 'Andry'){
	console.log('Привет, папа Андрей!')
} else if (myName === 'Tatiana'){
	console.log('Привет, мама Татьяна!')
} else if (myName === 'Sophiya'){
	console.log('Привет, сестра София!')
} else{
	console.log('Привет, незнакомец!')
}