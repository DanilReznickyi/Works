let lemonChiken = false
let beefWithBlackBean = true
let sweetAndSourPork = true

if (lemonChiken) {
    console.log('Отлично')
} else if(beefWithBlackBean){
    console.log('Хорошо')
} else if(sweetAndSourPork){
    console.log('Ладно')
} else {
    console.log('Сойдет')
}
