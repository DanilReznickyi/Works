let ageChild = 10
let isParents = true
let minAge = 12


console.log(ageChild >= minAge || isParents)