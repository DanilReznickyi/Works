function double(number){
	return number * 2
}
double(4)