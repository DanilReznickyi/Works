let compliments = ['апетитна', 'аристократична', 'блискуча', 'розкішна', 'збудлива', 'смачненька', 'запашна', 'дюймовочка', 'чудова', 'грайлива', 'кльова', 'кокетлива', 'цукерочка', 'красуня', 'королева', 'лялечка', 'любимка', 'наймиліша', 'неймовірна', 'нереальна', 'першокласна'];
let compliment = compliments[Math.floor(Math.random() * compliments.length)];
let answerCompliment = [];
let attempts = 10;
let foundMatch = false;

for (let i = 0; i < compliment.length; i++) {
  answerCompliment[i] = ' _ ';
}

let remainingCompliments = compliment.length;

while (remainingCompliments > 0 && attempts > 0) {
  alert(answerCompliment.join(''));
  let guess = prompt('Назви букву, зіронька.');

  if (guess === null) {
    break;
  } else if (guess.length !== 1) {
    alert('Будь ласка, введіть лише одну букву, цукерочка');
  } else {
    foundMatch = false;
    guess = guess.toLowerCase();

    for (let j = 0; j < compliment.length; j++) {
      if (compliment[j] === guess && answerCompliment[j] === ' _ ') {
        answerCompliment[j] = guess;
        remainingCompliments--;
        foundMatch = true;
      }
    }

    if (!foundMatch) {
      attempts--;
      alert('Квіточка, в тебе залишилось спроб - ' + attempts);
    }
  }
}

alert(answerCompliment.join(''));
alert('Ось твій комплімент, серденько: ' + compliment);









// Создайте здесь свои функции
// word: загаданное слово
var word = pickWord();
// answerArray: итоговый массив
var answerArray = setupAnswerArray(word);
// remainingLetters: сколько букв осталось угадать
var remainingLetters = word.length;
while (remainingLetters > 0) {
 showPlayerProgress(answerArray);
 // guess: ответ игрока
 var guess = getGuess();
 if (guess === null) {
 break;
 } else if (guess.length !== 1) {
 alert("Пожалуйста, введите одиночную букву.");
 } else {
 // correctGuesses: количество открытых букв
 var correctGuesses = updateGameState(guess, word,
answerArray);
 remainingLetters -= correctGuesses;
 }
}
showAnswerAndCongratulatePlayer(answerArray);



var pickWord = function () {
	// Возвращает случайно выбранное слово
 };
 var setupAnswerArray = function (word) {
	// Возвращает итоговый массив для заданного слова word
 };
 var showPlayerProgress = function (answerArray) {
	// С помощью alert отображает текущее состояние игры
 };
 var getGuess = function () {
	// Запрашивает ответ игрока с помощью prompt
 };
 var updateGameState = function (guess, word, answerArray) {
	// Обновляет answerArray согласно ответу игрока (guess)
	// возвращает число, обозначающее, сколько раз буква guess
	// встречается в слове, чтобы можно было обновить значение
	// remainingLetters
 };
 var showAnswerAndCongratulatePlayer = function (answerArray) {
	// С помощью alert показывает игроку отгаданное слово
	// и поз