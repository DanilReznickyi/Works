let namesBody = ['глаз','жепа','ухо']
let abjectives = ['вонючая','дырявая','пробитая']
let animals = ['крыса','выдра','мышь','обузьяна','коала']
function pickRandomWord (words){
	return words[Math.floor(Math.random() * words.length)]
}
let randomString = 'У тебя ' + pickRandomWord(namesBody) + " словно " + pickRandomWord(abjectives) + " " + pickRandomWord(animals) + "!!!"
console.log(randomString)
