function printMultipleTimes(howManyTimes, whatToDraw){
	for(i = 0; i < howManyTimes; i++){
		console.log(i + ' ' + whatToDraw)
	}
}

printMultipleTimes(5, '=^.^=')