// #1. Математические расчеты и функции
// Создайте две функции, add и multiply; пусть каждая принимает
// по два аргумента. Функция add должна складывать аргументы
// и возвращать результат, а функция multiply — перемножать
// аргументы.
// С помощью только этих двух функций вычислите следующее
// несложное выражение:
// 36325 * 9824 + 777



function add(number1,number2){
	return number1 + number2
}
function multiply(number1,number2){
	return number1 * number2
}
let a = add(multiply(36325,9824),777)
console.log(a)