// #2. Совпадают ли массивы?
// Напишите функцию areArraysSame, которая принимает два
// массива с числами в качестве аргументов. Она должна возвращать true, если эти массивы одинаковые (то есть содержат одни
// и те же числа в одном и том же порядке), или false, если массивы различаются. Убедитесь, что ваша функция работает правильно, запустив такой код:
// areArraysSame([1, 2, 3], [4, 5, 6]);
// false
// areArraysSame([1, 2, 3], [1, 2, 3]);
// true
// areArraysSame([1, 2, 3], [1, 2, 3, 4]);
// false


let firstArray = [1,2,3]
let secondArray = [1,2,3]
let thirdArray = [1, 2, 3, 4]

function areArraysSame(array1,array2){
	for (var i = 0; i < array1.length; i++) {
		if (array1[i] !== array2[i] || array1.length !== array2.length) {
		return false;
	} 
	}
	return true;
}

console.log(areArraysSame(firstArray,secondArray))
console.log(areArraysSame(secondArray,thirdArray))