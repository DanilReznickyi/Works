function pickRandomWord (words){
	return words[Math.floor(Math.random() * words.length)]
}
let randomWords = ['Планета','Цветок','Червяк',]

pickRandomWord(randomWords)